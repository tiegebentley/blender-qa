"""Animate + render all 18 beats of the step-flashing explainer.
Builds the scene once per 'scene group', keyframes camera + action per beat,
renders each beat to its own folder of PNG frames at the beat's VO duration.
Low-poly reference-channel style. EEVEE, 9:16.

Run: blender --background --python animate_roof.py -- <out_root>
Env: RENDER_RES (1080x1920), FPS (24), SAMPLES (24), GROUP (house|junction|all)
"""
import bpy, sys, os, math, json, mathutils
argv=sys.argv
out_root=argv[argv.index("--")+1] if "--" in argv else "/tmp/anim"
os.makedirs(out_root,exist_ok=True)
RES=os.getenv("RENDER_RES","1080x1920"); RX,RY=(int(x) for x in RES.split("x"))
FPS=int(os.getenv("FPS","24")); SAMPLES=int(os.getenv("SAMPLES","24"))
GROUP=os.getenv("GROUP","all")
HOUSE="./cottage.glb"
VO=json.load(open("./vo_meta.json"))
DUR={m["i"]:max(1.2,m["dur"]+0.3) for m in VO}  # pad a beat

def mat(name,rgb,rough=0.95,metal=0.0,spec=0.12):
    m=bpy.data.materials.new(name); m.use_nodes=True
    b=m.node_tree.nodes.get("Principled BSDF")
    b.inputs["Base Color"].default_value=(*rgb,1); b.inputs["Roughness"].default_value=rough
    try: b.inputs["Metallic"].default_value=metal
    except Exception: pass
    try: b.inputs["Specular IOR Level"].default_value=spec
    except Exception:
        try: b.inputs["Specular"].default_value=spec
        except Exception: pass
    return m

def cube(name,loc,size,rot=(0,0,0),m=None,bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=bpy.context.active_object; o.name=name
    o.scale=(size[0]/2,size[1]/2,size[2]/2); o.rotation_euler=rot
    if bevel:
        md=o.modifiers.new("b","BEVEL"); md.width=bevel; md.segments=2
    if m: o.data.materials.append(m)
    return o

def new_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene

def sky_light(scene):
    world=bpy.data.worlds.new("W"); scene.world=world; world.use_nodes=True
    bg=world.node_tree.nodes.get("Background"); bg.inputs[0].default_value=(0.53,0.70,0.86,1); bg.inputs[1].default_value=1.0
    C_CLOUD=mat("cloud",(0.97,0.98,1.0),rough=1.0,spec=0.0)
    for cx,cy,cz,s in [(-6,8,7,1.6),(5,10,8,2.0),(0,12,6.5,1.3),(8,7,7.5,1.4)]:
        bpy.ops.mesh.primitive_uv_sphere_add(location=(cx,cy,cz),radius=s)
        cl=bpy.context.active_object; cl.scale=(1.8,1.0,0.5); cl.data.materials.append(C_CLOUD)
        for p in cl.data.polygons: p.use_smooth=True
    bpy.ops.object.light_add(type='SUN',location=(6,-6,12)); su=bpy.context.active_object
    su.data.energy=3.2; su.data.angle=math.radians(10)
    su.rotation_euler=(math.radians(52),math.radians(10),math.radians(38)); su.data.color=(1.0,0.96,0.88)
    bpy.ops.object.light_add(type='AREA',location=(-7,-6,7)); a=bpy.context.active_object
    a.data.energy=150; a.data.size=14; a.data.color=(0.7,0.8,0.95)

def setup_cam(scene,look):
    bpy.ops.object.camera_add(); cam=bpy.context.active_object; scene.camera=cam; cam.data.lens=42
    bpy.ops.object.empty_add(location=look); t=bpy.context.active_object
    tc=cam.constraints.new('TRACK_TO'); tc.target=t; tc.track_axis='TRACK_NEGATIVE_Z'; tc.up_axis='UP_Y'
    return cam,t

def ease_all():
    for o in bpy.data.objects:
        if o.animation_data and o.animation_data.action:
            for fc in o.animation_data.action.fcurves:
                for kp in fc.keyframe_points: kp.interpolation='BEZIER'

def render_beat(scene,beat,cam_from,cam_to,look_from=None,look_to=None,tgt=None,extra_anim=None):
    dur=DUR[beat]; nf=max(2,int(round(dur*FPS)))
    scene.frame_start=1; scene.frame_end=nf; scene.render.fps=FPS
    cam=scene.camera
    cam.location=cam_from; cam.keyframe_insert("location",frame=1)
    cam.location=cam_to;   cam.keyframe_insert("location",frame=nf)
    if tgt is not None and look_from and look_to:
        tgt.location=look_from; tgt.keyframe_insert("location",frame=1)
        tgt.location=look_to;   tgt.keyframe_insert("location",frame=nf)
    if extra_anim: extra_anim(nf)
    ease_all()
    r=scene.render
    try: r.engine='BLENDER_EEVEE_NEXT'
    except Exception: r.engine='BLENDER_EEVEE'
    try: scene.eevee.taa_render_samples=SAMPLES; scene.eevee.use_shadows=True; scene.eevee.use_gtao=True
    except Exception: pass
    r.resolution_x=RX; r.resolution_y=RY; r.image_settings.file_format='PNG'
    bd=os.path.join(out_root,f"beat{beat:02d}"); os.makedirs(bd,exist_ok=True)
    r.filepath=os.path.join(bd,"f_")
    print(f"RENDER beat {beat} frames {nf} dur {dur:.2f}")
    bpy.ops.render.render(animation=True)
    print(f"BEAT_DONE {beat}")

# =================== HOUSE GROUP (beats 0,1,17) ===================
def do_house():
    scene=new_scene()
    bpy.ops.import_scene.gltf(filepath=HOUSE)
    for o in list(scene.objects):
        if o.type=='MESH': o.location.z += 0.39
    C_GRASS=mat("grass",(0.45,0.58,0.32)); C_SOIL=mat("soil",(0.40,0.24,0.13))
    cube("Ground",(0,0,-0.1),(60,60,0.2),m=C_GRASS)
    cube("SoilBlock",(0,0,-1.6),(60,60,3.0),m=C_SOIL)
    sky_light(scene)
    cam,tgt=setup_cam(scene,(0,0,3.0))
    # beat 0: slow orbit L->R, wide
    render_beat(scene,0,(11,-12,6),(8,-13,6),(0,0,3),(0,0,3),tgt)
    # beat 1: push in a little on the roof (rain runs off)
    render_beat(scene,1,(8,-13,6),(6,-10,5.5),(0,0,3),(0,1,3.5),tgt)
    # beat 17: pull back out, finished house
    render_beat(scene,17,(7,-11,5.5),(12,-14,7),(0,1,3.2),(0,0,3),tgt)

# =================== JUNCTION GROUP (beats 2-16) ===================
def build_junction(scene):
    C_SOIL=mat("soil",(0.40,0.24,0.13)); C_DECK=mat("deck",(0.80,0.68,0.46))
    C_SHGL=mat("shingle",(0.30,0.33,0.37)); C_SHGL2=mat("shingle2",(0.37,0.40,0.45))
    C_WALL=mat("wall",(0.76,0.42,0.33)); C_WALLM=mat("wallm",(0.90,0.84,0.74))
    C_RUST=mat("rust",(0.55,0.30,0.14)); C_GALV=mat("galv",(0.74,0.78,0.82),rough=0.4,metal=0.55,spec=0.6)
    C_TAR=mat("tar",(0.10,0.10,0.11),rough=0.6)
    PITCH=math.radians(28); GW=4.0
    cube("JWall",(0,1.6,1.6),(GW,0.4,3.2),m=C_WALL)
    for i,z in enumerate([0.6,1.2,1.8,2.4]): cube(f"JM{i}",(0,1.38,z),(GW,0.02,0.04),m=C_WALLM)
    dl=3.2; dcy=-1.4+(dl/2)*math.cos(PITCH); dcz=0.25+(dl/2)*math.sin(PITCH)
    cube("JDeck",(0,dcy,dcz),(GW,dl,0.14),rot=(PITCH,0,0),m=C_DECK)
    cube("JFill",(0,dcy,dcz-0.5),(GW,dl,0.9),rot=(PITCH,0,0),m=C_SOIL)
    courses=[]; n=8
    for rr in range(n):
        t=rr/(n-1); y=-1.3+t*(dl-0.4)*math.cos(PITCH); z=0.36+t*(dl-0.4)*math.sin(PITCH)
        m=C_SHGL if rr%2==0 else C_SHGL2
        courses.append(cube(f"JC{rr}",(0,y,z),(GW,0.36,0.08),rot=(PITCH,0,0),m=m,bevel=0.01))
    jy=-1.3+(dl-0.4)*math.cos(PITCH); jz=0.36+(dl-0.4)*math.sin(PITCH)
    tar=cube("Tar",(0,1.35,jz+0.08),(1.4,0.18,0.14),m=C_TAR)
    fr=cube("FR",(0,jy-0.1,jz+0.06),(1.6,0.5,0.04),rot=(PITCH,0,0),m=C_RUST,bevel=0.01)
    fw=cube("FW",(0,1.41,jz+0.33),(1.6,0.04,0.5),m=C_RUST,bevel=0.01)
    nr=cube("NR",(0,jy-0.1,jz+0.06),(1.6,0.5,0.04),rot=(PITCH,0,0),m=C_GALV,bevel=0.01)
    nw=cube("NW",(0,1.41,jz+0.33),(1.6,0.04,0.5),m=C_GALV,bevel=0.01)
    steps=[]
    for i in range(5):
        sy=jy-0.7+i*0.26; sz=0.36+((sy-(-1.3)))*math.tan(PITCH)+0.10
        steps.append(cube(f"SP{i}",(0,sy,sz),(0.62,0.3,0.03),rot=(PITCH,0,0),m=C_GALV,bevel=0.008))
    sky_light(scene)
    return dict(courses=courses,tar=tar,fr=fr,fw=fw,nr=nr,nw=nw,steps=steps,jy=jy,jz=jz,PITCH=PITCH,GW=GW)

def h(o,v): o.hide_viewport=v; o.hide_render=v
def key_vis(o,frame,visible):
    o.hide_viewport=not visible; o.hide_render=not visible
    o.keyframe_insert("hide_viewport",frame=frame); o.keyframe_insert("hide_render",frame=frame)

def do_junction():
    # Each beat rebuilds a fresh scene so object states/anim don't bleed. Cheap enough.
    beats_cfg = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    for beat in beats_cfg:
        scene=new_scene(); J=build_junction(scene)
        cam,tgt=setup_cam(scene,(0,0.4,J["jz"]))
        # reset to defaults: rusted visible, new+steps+tar hidden
        for o in (J["nr"],J["nw"],J["tar"],*J["steps"]): h(o,True)
        for o in (J["fr"],J["fw"]): h(o,False)
        jz=J["jz"]; PITCH=J["PITCH"]
        cf=(3.4,-5.4,2.2); ct=(2.8,-5.0,2.4); lf=(0,0.4,jz); lt=(0,0.5,jz+0.1)
        ea=None
        if beat in (2,3):       # edge meets wall / water in gap — push in
            for o in (J["fr"],J["fw"]): h(o,True)  # no flashing yet
            cf=(4.5,-6.5,2.6); ct=(3.0,-5.2,2.2)
        elif beat==4:           # tar jammed in — tar drops in
            for o in (J["fr"],J["fw"]): h(o,True)
            def ea(nf):
                t=J["tar"]; base=list(t.location)
                key_vis(t,1,False)
                t.location=(base[0],base[1],base[2]+1.2); t.keyframe_insert("location",frame=1)
                key_vis(t,max(2,int(nf*0.2)),True)
                t.location=base; t.keyframe_insert("location",frame=max(2,int(nf*0.5)))
        elif beat==5:           # tar dries/cracks/leak back — tar stays, slight shake
            for o in (J["fr"],J["fw"]): h(o,True)
            h(J["tar"],False)
        elif beat==6:           # strip slides in under shingles
            for o in (J["fr"],J["fw"]): h(o,True)
            def ea(nf):
                for o in (J["nr"],J["nw"]):
                    tgt_loc=list(o.location); off=(tgt_loc[0]+1.6,tgt_loc[1]-0.8,tgt_loc[2]+0.5)
                    key_vis(o,1,True); o.location=off; o.keyframe_insert("location",frame=1)
                    o.location=tgt_loc; o.keyframe_insert("location",frame=max(2,int(nf*0.75)))
        elif beat in (7,8):     # water runs out / 'this is flashing' — new strip in place, gentle orbit
            for o in (J["fr"],J["fw"]): h(o,True)
            for o in (J["nr"],J["nw"]): h(o,False)
            cf=(3.6,-5.4,2.2); ct=(2.2,-5.6,2.3)
        elif beat==9:           # single strip warps — show new strip, camera on the ends
            for o in (J["fr"],J["fw"]): h(o,True)
            for o in (J["nr"],J["nw"]): h(o,False)
            cf=(4.2,-5.0,2.2); ct=(3.4,-4.6,2.0)
        elif beat in (10,11):   # small pieces layer in, lap like scales
            for o in (J["fr"],J["fw"],J["nr"],J["nw"]): h(o,True)
            def ea(nf):
                for i,sp in enumerate(J["steps"]):
                    tgt_loc=list(sp.location); off=(tgt_loc[0]+1.2,tgt_loc[1]-0.5,tgt_loc[2]+0.4)
                    st=1+int(i*(nf*0.5)/len(J["steps"]))
                    key_vis(sp,st,True); sp.location=off; sp.keyframe_insert("location",frame=st)
                    sp.location=tgt_loc; sp.keyframe_insert("location",frame=min(nf,st+int(nf*0.4)))
        elif beat==12:          # 'this is step flashing' — steps in place, slow orbit
            for o in (J["fr"],J["fw"],J["nr"],J["nw"]): h(o,True)
            for sp in J["steps"]: h(sp,False)
            cf=(3.4,-5.2,2.2); ct=(2.0,-5.4,2.4)
        elif beat==13:          # rusts/lifts/leak back — rusted visible
            pass  # defaults (rusted visible)
        elif beat==14:          # pull shingles + slide rusted out
            def ea(nf):
                # lift top courses a touch
                for c in J["courses"][-2:]:
                    base=list(c.rotation_euler)
                    c.rotation_euler=base; c.keyframe_insert("rotation_euler",frame=1)
                    c.rotation_euler=(base[0]+math.radians(35),base[1],base[2]); c.keyframe_insert("rotation_euler",frame=max(2,int(nf*0.4)))
                for o in (J["fr"],J["fw"]):
                    base=list(o.location)
                    o.location=base; o.keyframe_insert("location",frame=max(2,int(nf*0.4)))
                    o.location=(base[0],base[1]-1.4,base[2]+0.8); o.keyframe_insert("location",frame=int(nf*0.85))
                    key_vis(o,int(nf*0.88),False)
        elif beat==15:          # tuck new in + press shingles down
            for o in (J["fr"],J["fw"]): h(o,True)
            def ea(nf):
                for o in (J["nr"],J["nw"]):
                    tgt_loc=list(o.location); off=(tgt_loc[0]+1.4,tgt_loc[1]-1.0,tgt_loc[2]+0.7)
                    key_vis(o,1,True); o.location=off; o.keyframe_insert("location",frame=1)
                    o.location=tgt_loc; o.keyframe_insert("location",frame=int(nf*0.6))
                for c in J["courses"][-2:]:
                    base=list(c.rotation_euler)
                    c.rotation_euler=(base[0]+math.radians(35),base[1],base[2]); c.keyframe_insert("rotation_euler",frame=1)
                    c.rotation_euler=base; c.keyframe_insert("rotation_euler",frame=int(nf*0.9))
        elif beat==16:          # water runs clear / dry — new flashing, slow push
            for o in (J["fr"],J["fw"]): h(o,True)
            for o in (J["nr"],J["nw"]): h(o,False)
            cf=(3.2,-5.2,2.2); ct=(2.4,-5.0,2.1)
        render_beat(scene,beat,cf,ct,lf,lt,tgt,ea)

if GROUP in ("house","all"): do_house()
if GROUP in ("junction","all"): do_junction()
print("ALL_BEATS_DONE")
